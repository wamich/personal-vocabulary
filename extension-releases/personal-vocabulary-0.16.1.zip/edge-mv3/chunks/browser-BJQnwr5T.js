import{a7 as a}from"./_virtual_wxt-plugins-783bO7HK.js";const s=a;export{s as b};
