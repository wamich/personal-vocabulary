const o={Host:"host",Keyword:"keyword",Reg:"reg"};export{o as R};
