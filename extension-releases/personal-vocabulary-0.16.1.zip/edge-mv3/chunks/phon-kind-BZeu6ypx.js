const U={US:"us",UK:"uk"},s={[U.US]:"en-US",[U.UK]:"en-GB"};export{U as P,s as a};
