import{ae as a,r as e}from"./_virtual_wxt-plugins-783bO7HK.js";const s=()=>{const s=e(new Map);return a(()=>{s.value=new Map}),[a=>e=>{s.value.set(a,e)},s]};export{s as u};
