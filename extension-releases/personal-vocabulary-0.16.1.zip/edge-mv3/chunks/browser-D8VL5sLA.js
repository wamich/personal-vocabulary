import{r as a,c as s}from"./_virtual_wxt-plugins-783bO7HK.js";const o=a(),i=s(()=>"ios"===o.value||"android"===o.value);export{i,o};
