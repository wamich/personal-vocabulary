const e={Word:"word",Sentence:"sentence",Article:"article"};Object.values(e);const t={Word:"{word}",Sentence:"{sentence}",Article:"{article}"};export{t as P,e as a};
