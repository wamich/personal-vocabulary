import{aW as s}from"./reset-DgHBc3al.js";import{o as r,s as t}from"./_virtual_wxt-plugins-783bO7HK.js";const a=()=>{const a=t(!1);return r(()=>{a.value=s()}),a};export{a as u};
