import{s as t}from"./plugin-theme-CbyOviLC.js";var e=t(Object.getPrototypeOf,Object);export{e as g};
