import{d as s,s as t}from"./_virtual_wxt-plugins-DeD45nRk.js";function a(a){const n=t();return s(()=>{n.value=a()},{flush:"sync"}),n}export{a as e};
