import{a7 as a}from"./_virtual_wxt-plugins-DeD45nRk.js";const s=a;export{s as b};
