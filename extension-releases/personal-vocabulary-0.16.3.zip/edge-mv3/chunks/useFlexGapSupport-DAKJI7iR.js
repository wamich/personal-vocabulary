import{aZ as s}from"./reset-CQ6zHwp7.js";import{o as r,s as t}from"./_virtual_wxt-plugins-DeD45nRk.js";const a=()=>{const a=t(!1);return r(()=>{a.value=s()}),a};export{a as u};
