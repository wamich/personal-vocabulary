import{a7 as a}from"./_virtual_wxt-plugins-DEeosE0w.js";const s=a;export{s as b};
