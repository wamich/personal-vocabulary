import{d as s,s as t}from"./_virtual_wxt-plugins-DEeosE0w.js";function a(a){const n=t();return s(()=>{n.value=a()},{flush:"sync"}),n}export{a as e};
