import{aZ as s}from"./reset-ByqX16UP.js";import{o as r,s as t}from"./_virtual_wxt-plugins-Da2rL0o2.js";const o=()=>{const o=t(!1);return r(()=>{o.value=s()}),o};export{o as u};
