import{f as s,s as t}from"./_virtual_wxt-plugins-Da2rL0o2.js";function n(n){const r=t();return s(()=>{r.value=n()},{flush:"sync"}),r}export{n as e};
