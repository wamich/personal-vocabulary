import{ac as a,r as s}from"./_virtual_wxt-plugins-Da2rL0o2.js";const t=()=>{const t=s(new Map);return a(()=>{t.value=new Map}),[a=>s=>{t.value.set(a,s)},t]};export{t as u};
