import{aZ as s}from"./reset-BFNHwoxz.js";import{o as r,s as t}from"./_virtual_wxt-plugins-DEeosE0w.js";const a=()=>{const a=t(!1);return r(()=>{a.value=s()}),a};export{a as u};
