import{aW as s}from"./reset-R1taD1cX.js";import{o as r,s as t}from"./_virtual_wxt-plugins-KYjFEVk8.js";const a=()=>{const a=t(!1);return r(()=>{a.value=s()}),a};export{a as u};
