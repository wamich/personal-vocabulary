import{a7 as a}from"./_virtual_wxt-plugins-KYjFEVk8.js";const s=a;export{s as b};
