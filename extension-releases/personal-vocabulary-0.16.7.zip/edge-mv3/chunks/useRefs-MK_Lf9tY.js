import{ab as a,r as s}from"./_virtual_wxt-plugins-CIhFK17B.js";const t=()=>{const t=s(new Map);return a(()=>{t.value=new Map}),[a=>s=>{t.value.set(a,s)},t]};export{t as u};
