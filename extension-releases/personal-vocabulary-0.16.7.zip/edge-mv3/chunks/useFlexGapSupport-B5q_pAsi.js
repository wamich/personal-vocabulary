import{aZ as s}from"./reset-C9M-jgYP.js";import{o as r,s as t}from"./_virtual_wxt-plugins-CIhFK17B.js";const o=()=>{const o=t(!1);return r(()=>{o.value=s()}),o};export{o as u};
