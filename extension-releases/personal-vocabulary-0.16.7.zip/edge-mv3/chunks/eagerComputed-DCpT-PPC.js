import{f as s,s as t}from"./_virtual_wxt-plugins-CIhFK17B.js";function n(n){const r=t();return s(()=>{r.value=n()},{flush:"sync"}),r}export{n as e};
