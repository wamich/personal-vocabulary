import{q as t}from"./plugin-theme-t8cqkQUF.js";var e=t(Object.getPrototypeOf,Object);export{e as g};
