import{r as a,c as s}from"./_virtual_wxt-plugins-CIhFK17B.js";const o=a(),i=s(()=>"ios"===o.value||"android"===o.value);export{i,o};
