import{x as s,H as r}from"./grck-B6nCmyfg.js";function n(n){const o=s();return r((()=>{o.value=n()}),{flush:"sync"}),o}export{n as e};
