import{g as a,ae as e}from"./grck-B6nCmyfg.js";const s=()=>{const s=a(new Map);return e((()=>{s.value=new Map})),[a=>e=>{s.value.set(a,e)},s]};export{s as u};
